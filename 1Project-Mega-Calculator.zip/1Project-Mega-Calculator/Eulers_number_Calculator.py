def Eulers_number_Calculator():
   print("Welcome to Euler's number writer")
   n=float(input("Enter your number which you want to double for the period \n"))
   a=(1/n) + 1
   e=a**n
   print("Your exponentially increased number is = ", e)
Eulers_number_Calculator()